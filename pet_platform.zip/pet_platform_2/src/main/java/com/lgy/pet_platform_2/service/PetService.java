package com.lgy.pet_platform_2.service;

import java.util.List;

import com.lgy.pet_platform_2.dto.PetDTO;


public interface PetService {
    void insertPet(PetDTO pet);
    List<PetDTO> getAllPets();
    PetDTO getPetById(int id);
    void updatePet(PetDTO pet);
	void deletePet(int id);
	List<PetDTO> getPetsByUserId(String user_id);
}